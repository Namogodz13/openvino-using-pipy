this program using python 3.11.5 and needed jupyter-lastest
#==========================================================
to open :
    1.open the folder 
    2.rename the redirect url to "cmd"
    3.run command(command promp only) "py -m jupyter lab"
#==========================================================
to download :
    "py -m pip install -r requirement.txt
#==========================================================